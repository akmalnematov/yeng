#!/usr/bin/env bash
set -e
python -m fast_ig_bot_light.bot